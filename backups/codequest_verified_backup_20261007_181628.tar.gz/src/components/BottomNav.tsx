import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Home,
  BookOpen,
  LayoutGrid,
  User,
  Settings,
  Code,
  Library,
  ChevronLeft,
  Circle,
  Square,
  Sparkles,
  X,
  Compass
} from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { playSound, triggerHaptic } from '../lib/sounds';

interface BottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function BottomNav({ activeTab, setActiveTab }: BottomNavProps) {
  const { t } = useLanguage();

  // Navigation mode: 'gestures' (modern iPhone / Pixel pill) or 'buttons' (Android 3-button nav)
  const [navMode, setNavMode] = useState<'gestures' | 'buttons'>(() => {
    return (localStorage.getItem('codequest_phone_nav_mode') as 'gestures' | 'buttons') || 'gestures';
  });

  // Recent apps / multi-tasking drawer sheet
  const [showRecents, setShowRecents] = useState(false);

  // Tab navigation history for phone Back button
  const [history, setHistory] = useState<string[]>([activeTab]);

  useEffect(() => {
    setHistory((prev) => {
      if (prev[prev.length - 1] === activeTab) return prev;
      return [...prev.slice(-15), activeTab];
    });
  }, [activeTab]);

  const handleSelectTab = (tabId: string) => {
    if (tabId === activeTab) {
      // Tapping active tab scrolls smoothly to top (standard phone UX)
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    playSound('click');
    triggerHaptic('light');
    setActiveTab(tabId);
    if (showRecents) setShowRecents(false);
  };

  const handlePhoneBack = () => {
    playSound('click');
    triggerHaptic('medium');
    if (showRecents) {
      setShowRecents(false);
      return;
    }
    if (history.length > 1) {
      const newHistory = [...history];
      newHistory.pop(); // remove current
      const previous = newHistory[newHistory.length - 1];
      setHistory(newHistory);
      setActiveTab(previous);
    } else if (activeTab !== 'home') {
      setActiveTab('home');
    }
  };

  const handlePhoneHome = () => {
    playSound('click');
    triggerHaptic('medium');
    setShowRecents(false);
    setActiveTab('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handlePhoneRecents = () => {
    playSound('click');
    triggerHaptic('medium');
    setShowRecents((prev) => !prev);
  };

  const toggleNavMode = () => {
    playSound('click');
    triggerHaptic('light');
    const nextMode = navMode === 'gestures' ? 'buttons' : 'gestures';
    setNavMode(nextMode);
    localStorage.setItem('codequest_phone_nav_mode', nextMode);
  };

  // ALL ORIGINAL TABS PRESERVED EXACTLY
  const tabs = [
    { id: 'home', icon: Home, label: 'Home', desc: 'Global leaderboard & highlights' },
    { id: 'learn', icon: BookOpen, label: 'Learn', desc: 'Interactive coding tracks' },
    { id: 'playground', icon: Code, label: 'Play', desc: 'Code editor & live sandbox' },
    { id: 'library', icon: Library, label: 'Library', desc: 'Snippets & references' },
    { id: 'projects', icon: LayoutGrid, label: 'Projects', desc: 'Showcase projects' },
    { id: 'profile', icon: User, label: 'Profile', desc: 'Stats, badges & achievements' },
    { id: 'settings', icon: Settings, label: 'Settings', desc: 'Themes, audio & preferences' }
  ];

  return (
    <>
      {/* Phone App Switcher / Recent Apps Modal */}
      <AnimatePresence>
        {showRecents && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[110] bg-black/60 backdrop-blur-md flex flex-col justify-end p-4 pb-28 sm:pb-32"
            onClick={() => setShowRecents(false)}
          >
            <motion.div
              initial={{ y: '100%', opacity: 0.5 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: '100%', opacity: 0 }}
              transition={{ type: 'spring', damping: 26, stiffness: 320 }}
              className="max-w-md w-full mx-auto bg-surface-card border border-white/20 dark:border-white/10 rounded-3xl p-5 shadow-2xl relative overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header */}
              <div className="flex items-center justify-between mb-4 pb-3 border-b border-white/10">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-brand-500/20 text-brand-500 flex items-center justify-center">
                    <Compass className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-content-primary">{t('Phone Navigation Deck')}</h3>
                    <p className="text-[11px] text-content-muted">{t('Select any app screen')}</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowRecents(false)}
                  className="p-1.5 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-content-muted"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Grid of screens */}
              <div className="grid grid-cols-2 gap-2.5 max-h-[50vh] overflow-y-auto pr-1">
                {tabs.map((tab) => {
                  const isActive = activeTab === tab.id;
                  const Icon = tab.icon;
                  return (
                    <motion.button
                      key={tab.id}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => handleSelectTab(tab.id)}
                      className={`flex flex-col items-start p-3 rounded-2xl text-left border transition-all relative overflow-hidden ${
                        isActive
                          ? 'bg-brand-500/15 border-brand-500/40 shadow-sm'
                          : 'bg-surface-elevated/60 border-white/10 hover:border-brand-500/30'
                      }`}
                    >
                      <div className="flex items-center justify-between w-full mb-2">
                        <div
                          className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                            isActive
                              ? 'bg-brand-500 text-white shadow-md'
                              : 'bg-surface-main text-content-secondary'
                          }`}
                        >
                          <Icon className="w-4 h-4" />
                        </div>
                        {isActive && (
                          <span className="text-[10px] font-extrabold uppercase px-1.5 py-0.5 rounded-full bg-brand-500 text-white">
                            Active
                          </span>
                        )}
                      </div>
                      <span className="text-xs font-bold text-content-primary">{t(tab.label)}</span>
                      <span className="text-[10px] text-content-muted line-clamp-1">{t(tab.desc)}</span>
                    </motion.button>
                  );
                })}
              </div>

              {/* System Nav mode switcher */}
              <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between">
                <span className="text-[11px] text-content-muted">{t('System Navigation Style')}</span>
                <button
                  onClick={toggleNavMode}
                  className="text-[11px] font-bold px-3 py-1 rounded-full bg-brand-500/10 text-brand-500 hover:bg-brand-500/20 transition-colors flex items-center gap-1.5"
                >
                  <Sparkles className="w-3 h-3" />
                  {navMode === 'gestures' ? t('Switch to 3-Button Nav') : t('Switch to Gesture Bar')}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Phone Navigation Bar */}
      <div className="fixed bottom-0 left-0 right-0 sm:bottom-4 sm:left-1/2 sm:-translate-x-1/2 sm:w-[680px] sm:min-w-0 z-[100] transform-gpu">
        {/* Outer Phone Shell */}
        <div className="relative rounded-t-[28px] sm:rounded-[32px] bg-surface-card/95 dark:bg-[#0c111e]/95 backdrop-blur-2xl border-t border-white/30 dark:border-white/10 sm:border sm:border-white/30 sm:dark:border-white/15 shadow-[0_-10px_35px_rgba(0,0,0,0.15)] sm:shadow-[0_15px_45px_rgba(0,0,0,0.25)] overflow-hidden">
          {/* Subtle phone screen edge specular reflection line */}
          <div className="absolute top-0 inset-x-8 h-[1px] bg-gradient-to-r from-transparent via-white/40 dark:via-white/20 to-transparent pointer-events-none" />

          {/* Row 1: The 7 App Tabs (Phone Application Navigation Bar) */}
          <div className="flex items-center justify-between px-1.5 pt-2 pb-1 sm:px-3 sm:pt-2.5 sm:pb-1.5 w-full">
            {tabs.map((tab) => {
              const isActive = activeTab === tab.id;
              const Icon = tab.icon;

              return (
                <motion.button
                  key={tab.id}
                  onClick={() => handleSelectTab(tab.id)}
                  className={`flex flex-col items-center justify-center py-1 px-1 sm:px-2 rounded-2xl transition-all relative flex-1 min-w-0 group select-none`}
                  whileTap={{ scale: 0.88 }}
                  aria-label={tab.label}
                >
                  {/* Phone Active Capsule / Pill Indicator */}
                  {isActive && (
                    <motion.div
                      layoutId="phone-tab-active-pill"
                      className="absolute inset-0 bg-brand-500/15 dark:bg-brand-500/25 rounded-2xl border border-brand-500/30"
                      transition={{ type: 'spring', stiffness: 450, damping: 30 }}
                    />
                  )}

                  {/* Icon with micro bounce on active */}
                  <div className="relative z-10 flex items-center justify-center">
                    <motion.div
                      animate={isActive ? { scale: [1, 1.18, 1], y: [0, -1, 0] } : { scale: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                      className={`${
                        isActive
                          ? 'text-brand-500 dark:text-brand-400 drop-shadow-[0_2px_8px_rgba(99,102,241,0.4)]'
                          : 'text-content-muted group-hover:text-content-primary transition-colors'
                      }`}
                    >
                      <Icon className="w-5 h-5 sm:w-5.5 sm:h-5.5 shrink-0" />
                    </motion.div>
                  </div>

                  {/* Label */}
                  <span
                    className={`text-[9px] sm:text-[10px] font-bold z-10 relative mt-0.5 truncate max-w-full text-center tracking-tight transition-colors ${
                      isActive
                        ? 'text-brand-600 dark:text-brand-300 font-extrabold'
                        : 'text-content-muted group-hover:text-content-primary'
                    }`}
                  >
                    {t(tab.label)}
                  </span>

                  {/* Tiny Active Phone Dot Indicator */}
                  {isActive && (
                    <motion.span
                      layoutId="phone-tab-active-dot"
                      className="w-1 h-1 rounded-full bg-brand-500 dark:bg-brand-400 mt-0.5 z-10"
                      transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                    />
                  )}
                </motion.button>
              );
            })}
          </div>

          {/* Row 2: Phone Bottom System Navigation Bar (Gesture Pill or Android 3-Button) */}
          <div className="w-full border-t border-black/5 dark:border-white/5 bg-black/[0.02] dark:bg-white/[0.02] px-4 py-1 flex items-center justify-center select-none">
            {navMode === 'gestures' ? (
              /* Modern Smartphone Home Gesture Bar (iOS / Pixel / Samsung Gesture Pill) */
              <div className="w-full flex items-center justify-between max-w-sm mx-auto h-5">
                {/* Subtle back cue */}
                <button
                  onClick={handlePhoneBack}
                  title={t('Back')}
                  className="p-1 text-content-muted/60 hover:text-content-primary transition-colors rounded-full active:scale-90"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>

                {/* The Classic Phone Home Indicator Bar */}
                <motion.button
                  onClick={handlePhoneHome}
                  onDoubleClick={toggleNavMode}
                  whileTap={{ scale: 0.95 }}
                  title={t('Phone Home Indicator (Tap to scroll top / Double tap to change nav style)')}
                  className="group flex flex-col items-center justify-center py-1 px-4"
                >
                  <div className="w-28 sm:w-36 h-1 rounded-full bg-content-muted/40 group-hover:bg-brand-500/80 group-active:w-32 transition-all duration-200" />
                </motion.button>

                {/* Recents overview cue */}
                <button
                  onClick={handlePhoneRecents}
                  title={t('Recent Apps')}
                  className="p-1 text-content-muted/60 hover:text-content-primary transition-colors rounded-full active:scale-90"
                >
                  <Square className="w-3 h-3" />
                </button>
              </div>
            ) : (
              /* Android 3-Button Phone Navigation Bar (Back ◀, Home ●, Recents ◾) */
              <div className="w-full flex items-center justify-around max-w-xs mx-auto h-6">
                {/* 1. Android Back Button ◀ */}
                <motion.button
                  onClick={handlePhoneBack}
                  whileTap={{ scale: 0.85 }}
                  title={t('Back')}
                  className="p-2 text-content-muted hover:text-content-primary active:text-brand-500 transition-colors"
                >
                  <ChevronLeft className="w-4 h-4 stroke-[2.5]" />
                </motion.button>

                {/* 2. Android Home Button ● */}
                <motion.button
                  onClick={handlePhoneHome}
                  whileTap={{ scale: 0.85 }}
                  title={t('Home')}
                  className="p-2 text-content-muted hover:text-content-primary active:text-brand-500 transition-colors"
                >
                  <Circle className="w-3.5 h-3.5 stroke-[2.5] fill-current" />
                </motion.button>

                {/* 3. Android Recents Button ◾ */}
                <motion.button
                  onClick={handlePhoneRecents}
                  whileTap={{ scale: 0.85 }}
                  title={t('Recent Screens')}
                  className="p-2 text-content-muted hover:text-content-primary active:text-brand-500 transition-colors"
                >
                  <Square className="w-3.5 h-3.5 stroke-[2.5]" />
                </motion.button>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
